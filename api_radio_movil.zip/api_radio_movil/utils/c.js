export const WS_SEND_ALERT = 1;
export const WS_SEND_CHANGE = 2;